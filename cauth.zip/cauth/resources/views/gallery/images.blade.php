<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="{{ asset('bootstrap-3.1.1/css/bootstrap.min.css') }}">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body>
    
	<div class="container">
	<h2>GALLERY</h2>
	<form>
		<div class="form-group">

		<select id="category" class="form-control" >
			<option value=''>Select category</option>
			@foreach($allcategory as $list)
				<option value="{{$list->id}}">{{$list->category}}</option>
			@endforeach
		</select>
		

		<br/><br/>
 <div class="row"></div>
		<br/><br/>

		<div id="image" class="" >   </div>
		<br/>
		
		</div>
	  </form>
	</div>

   <script src="{{ asset('jquery-3.5.0.min.js') }}"></script>
		<script>

		jQuery(document).ready(function(){

			var cid ='';
			jQuery('#category').change(function(){
			
				cid=jQuery(this).val();
				//alert(cid);
				jQuery.ajax({
					url:'/getImages',
					type:'post',
					data:'cid='+cid+'&_token={{csrf_token()}}',
					success:function(result){
						console.log(result);
						jQuery('#image').html('')
						jQuery('#image').html(result)
					}
				});
			});
			

   if(cid =='')
   {
   			jQuery.ajax({
					url:'/getImages',
					type:'post',
					data:'cid='+cid+'&_token={{csrf_token()}}',
					success:function(result){
						console.log(result);
						jQuery('#image').html('')
						jQuery('#image').html(result)
					}
				});
   }
		
			
		});
			
		</script>
  </body>
</html>
		
		