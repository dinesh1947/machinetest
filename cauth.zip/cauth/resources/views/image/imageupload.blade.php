<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="csrf-token" content="{{ csrf_token() }}">

	
	 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
   <script src="{{ asset('jquery-3.5.0.min.js') }}"></script>
	<style>
		img{
			width: 60px;
		}
	</style>
</head>
<body>
	<div class="container">

		<h1>Image Uploader</h1>
		
		<hr>

<form action="imagesave"  id ="main_form" method="POST" enctype="multipart/form-data">
	@csrf
        <input type="file" name="images[]" id="images" multiple><br> 
         <!-- <input type="file" name="myimages[]" multiple/> -->
         <div id="images-to-upload">
	</div><!-- end #images-to-upload -->

	<select name ="category" class="form-select">
  	<option value=''>Select category</option>
			@foreach($allcategory as $list)
				<option value="{{$list->id}}">{{$list->category}}</option>
			@endforeach
	</select>
	<br><br>




         <input type="submit" name="submit"/>
      </form>

	<hr>

	</div>





	<script>
		var fileCollection = new Array();

		$('#images').on('change',function(e){
			var files = e.target.files;
			$.each(files, function(i, file){
			
				fileCollection.push(file);
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e){

					var template = ''+
						'<img src="'+e.target.result+'"> '+
						'<label>Image Title</label> <input type="text" name="title[]"><br>';
					$('#images-to-upload').append(template);
				};
			});
		});



    $(document).on('submit','form',function(e){

    	$.ajaxSetup({
	headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
	});

        e.preventDefault();
	$.ajax({
            //alert("ff");
            url:$(this).attr('action'),
            method:$(this).attr('method'),
            data:new FormData(this),
            processData:false,
            dataType:'json',
            contentType:false,
	            beforeSend:function(){
	                $(document).find('span.error-text').text('');
	            },
	            success:function(data){
 $('#main_form')[0].reset();
         alert(data.msg);
	            }
        });

	});


	</script>
</body>
</html>