<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Models\Image;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
class MultipleImageController extends Controller
{
    

    public function index(Request $request){
         
         $data['allcategory']=DB::table('category')->orderBy('category','asc')->get();
       // return $data;
         return view('image.imageupload', $data);
    }



    function save(Request $request){

        foreach ($_FILES['images']['name'] as $i => $name)  
        {
                $new_name = md5(rand()).'.'.pathinfo($name, PATHINFO_EXTENSION);  
                  $sourcePath = $_FILES['images']['tmp_name'][$i];  
            $basepath = base_path();
                 $relativepath = "/public/files/".$new_name;  
                 $targetPath = $basepath."".$relativepath; 

                  if(move_uploaded_file($sourcePath, $targetPath))  
                {  
                     $image =  new Image;
             $image->title = $_POST['title'][$i];
             $image->name = $name;
             $image->type = $_FILES['images']['type'][$i];
             $image->category_id = $_POST['category'];
             $image->size = $_FILES['images']['size'][$i];
             $image->path = $relativepath ;
             
               $save = $image->save();

            if($save){
                    return response()->json(['status'=>1, 'msg'=>'images have been successfully uploaded']);
                }

                } 
                
        }

    }





}
