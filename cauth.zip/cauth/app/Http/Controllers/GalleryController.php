<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GalleryController extends Controller
{
   

    public function index(Request $request){
         $data['allcategory']=DB::table('category')->orderBy('category','asc')->get();
         return view('gallery.images',$data);
    }




    public function getImages(Request $request){
         $cid=$request->post('cid');
         if($cid != '')
         {
        $images=DB::table('images')->where('category_id',$cid)->get();
            }
        else
            {
            $images=DB::table('images')->get();
            }
        $html='';
        foreach($images as $list){
  $html.='<div class="col-md-4"><div class="thumbnail">  <img src="http://localhost/cauth'.$list->path.'" alt="Nature" style="width:100%">  </div></div>';
        }
        echo $html;
       
    }
    








}
