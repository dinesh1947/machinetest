<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    
	<div class="container">
	<h2>GALLERY</h2>
	<form>
		<div class="form-group">

		<select id="category" class="form-control" >
			<option value=''>Select category</option>
			<?php $__currentLoopData = $allcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($list->id); ?>"><?php echo e($list->category); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		


		<br/><br/><br/><br/><br/>
		<div id="image" class="" >   </div>
		<br/>
		

		</div>
	  </form>
	</div>

   <script src="<?php echo e(asset('jquery-3.5.0.min.js')); ?>"></script>
		<script>

		jQuery(document).ready(function(){

			var cid ='';
			jQuery('#category').change(function(){
			
				cid=jQuery(this).val();
				alert(cid);
				jQuery.ajax({
					url:'/getImages',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){
						console.log(result);
						jQuery('#image').html('')
						jQuery('#image').html(result)
					}
				});
			});
			


   if(cid =='')
   {
   	alert("all");

   			jQuery.ajax({
					url:'/getImages',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){
						console.log(result);
						jQuery('#image').html('')
						jQuery('#image').html(result)
					}
				});
   }
		


			
		});
			
		</script>
  </body>
</html>
		
		<?php /**PATH /home/dc/Desktop/cauth/resources/views/gallery/images.blade.php ENDPATH**/ ?>