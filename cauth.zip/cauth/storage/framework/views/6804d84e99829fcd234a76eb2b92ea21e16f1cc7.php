<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	
	 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
   <script src="<?php echo e(asset('jquery-3.5.0.min.js')); ?>"></script>
	<style>
		img{
			width: 40px;
		}
	</style>
</head>
<body>
	<div class="container">

		<h1>Image Uploader</h1>

		
		<hr>
		


<form action="imagesave" method="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
        <input type="file" name="images[]" id="images" multiple><br> 
         <!-- <input type="file" name="myimages[]" multiple/> -->
         <div id="images-to-upload">
	</div><!-- end #images-to-upload -->

	<select name ="category" class="form-select">
  	<option >select category</option>
 	 <option selected value="1">Nature</option>
 	 <option value="2">Animal</option>
 	 <option value="3">Technology</option>
 	 <option value="4">car</option>
	</select>
	<br><br>
         <input type="submit" name="submit"/>
      </form>






		<hr>

		<!-- <a href="#" class="btn btn-sm btn-success">Upload all images</a>
 -->
	</div><!-- end .container -->


	<script>

		//indirect ajax
		//file collection array
		var fileCollection = new Array();

		$('#images').on('change',function(e){

			var files = e.target.files;

			$.each(files, function(i, file){
				console.log(file);

				fileCollection.push(file);

				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e){

					var template = ''+
						'<img src="'+e.target.result+'"> '+
						'<label>Image Title</label> <input type="text" name="title[]"><br>';
						

					$('#images-to-upload').append(template);
				};

			});

		});








    $(document).on('submit','form',function(e){

    	$.ajaxSetup({
	headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
	});

	//alert("ddddd");

        e.preventDefault();

	$.ajax({
            //alert("ff");
            url:$(this).attr('action'),
            method:$(this).attr('method'),
            data:new FormData(this),
            processData:false,
            dataType:'json',
            contentType:false,
	            beforeSend:function(){
	                $(document).find('span.error-text').text('');
	            },
	            success:function(data){


	            }
        });

		

	});









		//more development in coming time........

		//subscribe, share, like, comment................

		//thanks for watching.................................
	</script>
</body>
</html><?php /**PATH /home/dc/Desktop/cauth/resources/views/image/imageupload.blade.php ENDPATH**/ ?>