$(function(){
              
    $("#main_form").on('submit', function(e){
        e.preventDefault();



        $.ajax({

            //alert("ff");
            url:$(this).attr('action'),
            method:$(this).attr('method'),
            data:new FormData(this),
            processData:false,
            dataType:'json',
            contentType:false,
            beforeSend:function(){
                $(document).find('span.error-text').text('');
            },
            success:function(data){
                if(data.status == 0){
                    console.log(data.error);
                    $.each(data.error, function(prefix, val){
                        if(prefix =='name') 
                        {
                            $('span.'+prefix+'_error').text("The first Name is required.");
                        }
                        else if(prefix =='lname')
                        {
                             $('span.'+prefix+'_error').text("The last Name is required.");
                        }
                        else{
                            $('span.'+prefix+'_error').text(val[0]);
                        }

                        
                    });
                }else{
                    $('#main_form')[0].reset();
                    alert(data.msg);
                }
            }
        });

     




    });
});